package com.bastianarf.desawisataponorogo.view.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.bastianarf.desawisataponorogo.viewmodel.FavoriteViewModel
import com.bastianarf.desawisataponorogo.adapters.MainAdapter
import com.bastianarf.desawisataponorogo.databinding.FragmentFavoriteBinding
import com.bastianarf.desawisataponorogo.utilities.Content
import com.google.firebase.auth.FirebaseAuth

class FavoriteFragment : Fragment() {

    private var _binding: FragmentFavoriteBinding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: FavoriteViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFavoriteBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(this).get(FavoriteViewModel::class.java)

        val recyclerViewFavoriteContent = binding.rvFavorite
        recyclerViewFavoriteContent.layoutManager = LinearLayoutManager(context)

        val firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser

        viewModel.favoriteContents.observe(viewLifecycleOwner) { contents ->
            val mainAdapter = MainAdapter(requireContext(), contents as MutableList<Content>)
            binding.rvFavorite.adapter = mainAdapter
        }

        currentUser?.uid?.let { viewModel.fetchFavorites(it) }
    }
}