package com.bastianarf.desawisataponorogo.viewmodel

import android.app.Application
import android.util.Patterns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase

class LoginViewModel(application: Application) : AndroidViewModel(application) {

    val auth: FirebaseAuth = Firebase.auth
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()

    val email = MutableLiveData<String>()
    val password = MutableLiveData<String>()
    val isLoginEnabled = MediatorLiveData<Boolean>().apply {
        addSource(email) { checkInputValidity() }
        addSource(password) { checkInputValidity() }
    }
    val loginResult = MutableLiveData<Boolean>()
    val loginError = MutableLiveData<String>()
    val navigateToInputBio = MutableLiveData<Boolean>()
    val navigateToMain = MutableLiveData<Boolean>()

    private fun checkInputValidity() {
        val emailIsValid = Patterns.EMAIL_ADDRESS.matcher(email.value ?: "").matches()
        val passwordIsValid = (password.value?.length ?: 0) >= 8
        isLoginEnabled.value = emailIsValid && passwordIsValid
    }

    fun signIn() {
        val emailValue = email.value ?: ""
        val passwordValue = password.value ?: ""
        auth.signInWithEmailAndPassword(emailValue, passwordValue)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    checkUserDetails()
                } else {
                    loginError.value = "Login failed. Please try again."
                }
            }
    }

    fun checkUserDetails() {
        val user = auth.currentUser
        user?.let { currentUser ->
            val userId = currentUser.uid
            val userRef = firestore.collection("users").document(userId)
            userRef.get()
                .addOnSuccessListener { documentSnapshot ->
                    val bio = documentSnapshot.getString("bio")
                    val avatar = documentSnapshot.getString("avatar")
                    if (bio.isNullOrEmpty() && avatar.isNullOrEmpty()) {
                        navigateToInputBio.value = true
                    } else {
                        navigateToMain.value = true
                    }
                }
                .addOnFailureListener { exception ->
                    loginError.value = "Error: ${exception.message}"
                }
        }
    }
}
