package com.bastianarf.desawisataponorogo.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase

class RegisterViewModel(application: Application) : AndroidViewModel(application) {

    private val auth: FirebaseAuth = Firebase.auth
    private val db = FirebaseFirestore.getInstance()

    private val _registrationResult = MutableLiveData<Result<Boolean>>()
    val registrationResult: LiveData<Result<Boolean>> = _registrationResult

    fun registerUser(email: String, password: String, fullName: String, nickName: String, bio: String, avatar: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    val userValues = hashMapOf(
                        "email" to email,
                        "fullName" to fullName,
                        "nickName" to nickName,
                        "bio" to bio,
                        "avatar" to avatar
                    )

                    db.collection("users").document(user?.uid!!)
                        .set(userValues)
                        .addOnSuccessListener {
                            _registrationResult.postValue(Result.success(true))
                        }
                        .addOnFailureListener {
                            _registrationResult.postValue(Result.failure(it))
                        }
                } else {
                    _registrationResult.postValue(Result.failure(task.exception ?: Exception("Registration failed")))
                }
            }
    }
}
