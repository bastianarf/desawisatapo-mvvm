package com.bastianarf.desawisataponorogo.model

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.bastianarf.desawisataponorogo.utilities.Content
import com.google.firebase.firestore.FirebaseFirestore

class MainRepository {

    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
    private val _contents = MutableLiveData<List<Content>>()
    val contents: LiveData<List<Content>> get() = _contents

    fun fillingTheContent() {
        db.collection("contents").limit(10)
            .get()
            .addOnSuccessListener { documents ->
                val contentsList = mutableListOf<Content>()
                for (document in documents) {
                    val content = document.toObject(Content::class.java)
                    content.documentId = document.id
                    contentsList.add(content)
                }
                _contents.value = contentsList
            }
            .addOnFailureListener { exception ->
                Log.d("MainRepository", "Error getting documents : ", exception)
            }
    }

    fun searchContents(query: String) {
        if (query.isEmpty()) {
            fillingTheContent()
            return
        }

        val endQuery = query + "\uf8ff"

        db.collection("contents")
            .whereGreaterThanOrEqualTo("name", query)
            .whereLessThanOrEqualTo("name", endQuery)
            .get()
            .addOnSuccessListener { documents ->
                val searchResults = mutableListOf<Content>()
                for (document in documents) {
                    val content = document.toObject(Content::class.java)
                    content.documentId = document.id
                    searchResults.add(content)
                }
                _contents.value = searchResults
            }
            .addOnFailureListener { exception ->
                Log.d("MainRepository", "Error getting documents : ", exception)
            }
    }

    fun filterContents(category: String) {
        db.collection("contents")
            .whereEqualTo("categories", category)
            .get()
            .addOnSuccessListener { documents ->
                val filteredResults = mutableListOf<Content>()
                for (document in documents) {
                    val content = document.toObject(Content::class.java)
                    content.documentId = document.id
                    filteredResults.add(content)
                }
                _contents.value = filteredResults
            }
            .addOnFailureListener { exception ->
                Log.d("MainRepository", "Error getting documents : ", exception)
            }
    }
}
