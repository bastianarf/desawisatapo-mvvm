package com.bastianarf.desawisataponorogo.customview

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import androidx.appcompat.widget.AppCompatEditText
import com.bastianarf.desawisataponorogo.R


@SuppressLint("ClickableViewAccessibility")
class MyReviewEditText(context: Context, attrs: AttributeSet) : AppCompatEditText(context, attrs)
{
    interface SendButtonClickListener {
        fun onSendButtonClick(text: String)
    }

    private var sendButtonClickListener: SendButtonClickListener? = null
    @SuppressLint("UseCompatLoadingForDrawables")
    private val sendButtonDrawable: Drawable? = context.getDrawable(R.drawable.ic_baseline_send_button_24)

    init {
        // set the bound for the drawable (adjust as needed)
        sendButtonDrawable?.setBounds(
            0,
            0,
            sendButtonDrawable.intrinsicWidth,
            sendButtonDrawable.intrinsicHeight
        )

        // set the click listener for drawable (send button)
        this.setOnTouchListener{ _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                if (event.rawX >= (right - compoundPaddingRight)) {
                    sendButtonClickListener?.onSendButtonClick(text.toString())
                    return@setOnTouchListener true
                }
            }
            false
        }

        // Add a TextWatcher to show/hide the send button based on the text content
        this.addTextChangedListener(object: TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                Log.d("MyReviewEditText", "afterTextChanged: ${s.toString()}")
                updateSendButtonVisibility()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        // Initially hide the send button if there's no text
        updateSendButtonVisibility()
    }

    private fun updateSendButtonVisibility() {
        if (text.isNullOrEmpty()) {
            Log.d("MyReviewEditText", "updateSendButtonVisibility: Hiding send button")
            setCompoundDrawables(null, null, null, null)
        } else {
            Log.d("MyReviewEditText", "updateSendButtonVisibility: Showing send button")
            setCompoundDrawables(null, null, sendButtonDrawable, null)
        }
    }

    fun setSendButtonClickListener(listener: SendButtonClickListener) {
        this.sendButtonClickListener = listener
    }


   override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
    }

}