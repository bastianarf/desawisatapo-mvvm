package com.bastianarf.desawisataponorogo.view.activity

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bastianarf.desawisataponorogo.R
import com.bastianarf.desawisataponorogo.viewmodel.RegisterViewModel
import com.bastianarf.desawisataponorogo.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth

// RegisterActivity.kt
class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var registerViewModel: RegisterViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        registerViewModel = ViewModelProvider(this).get(RegisterViewModel::class.java)
        actionClick()

        registerViewModel.registrationResult.observe(this, Observer { result ->
            result.onSuccess {
                showRegistrationSuccessDialog()
            }.onFailure {
                showErrorToast(it.message)
            }
        })
    }

    private fun actionClick() {
        binding.btnRegister.setOnClickListener {
            val fullName = binding.etRegisterFullname.text.toString()
            val nickName = binding.etRegisterNickname.text.toString()
            val email = binding.etRegisterEmail.text.toString()
            val password = binding.etRegisterPassword.text.toString()
            val confirmPassword = binding.etConfirmPassword.text.toString()
            val bio = ""
            val avatar = ""

            if (password == confirmPassword) {
                when {
                    fullName.isEmpty() -> binding.registerFullnameLayout.error = "Masukkan Nama Lengkap"
                    nickName.isEmpty() -> binding.registerNicknameLayout.error = "Masukkan nickname"
                    email.isEmpty() -> binding.registerEmailLayout.error = "Masukkan Email"
                    password.isEmpty() -> binding.registerPasswordLayout.error = "Masukkan Password"
                    confirmPassword.isEmpty() -> binding.confirmPasswordLayout.error = "Masukkan konfirmasi password"
                    else -> registerViewModel.registerUser(email, password, fullName, nickName, bio, avatar)
                }
            } else {
                binding.confirmPasswordLayout.error = getString(R.string.error_confirm_password)
            }
        }

        binding.toLogin.setOnClickListener {
            goToLoginActivity()
        }
    }

    private fun showRegistrationSuccessDialog() {
        AlertDialog.Builder(this).apply {
            setTitle("Registrasi Berhasil")
            setMessage("Kembali ke halaman Sign In")
            setPositiveButton("Ok") { _, _ ->
                FirebaseAuth.getInstance().signOut()
                goToLoginActivity()
                finish()
            }
            create()
            show()
        }
    }

    private fun showErrorToast(message: String?) {
        Toast.makeText(this, message ?: "Error registering", Toast.LENGTH_SHORT).show()
    }

    private fun goToLoginActivity() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }
}
