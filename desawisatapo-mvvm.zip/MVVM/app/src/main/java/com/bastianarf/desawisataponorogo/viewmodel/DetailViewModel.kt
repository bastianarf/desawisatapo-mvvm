package com.bastianarf.desawisataponorogo.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.bastianarf.desawisataponorogo.model.ContentRepository
import com.bastianarf.desawisataponorogo.utilities.Review
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot

class DetailViewModel(private val repository: ContentRepository) : ViewModel() {

    private val _content = MutableLiveData<DocumentSnapshot>()
    val content: LiveData<DocumentSnapshot> get() = _content

    private val _isFavorite = MutableLiveData<Boolean>()
    val isFavorite: LiveData<Boolean> get() = _isFavorite

    private val _favoriteChangedEvent = MutableLiveData<Boolean>()
    val favoriteChangedEvent: LiveData<Boolean> get() = _favoriteChangedEvent

    private val _reviews = MutableLiveData<List<Review>>()
    val reviews: LiveData<List<Review>> get() = _reviews

    fun fetchContent(documentId: String) {
        repository.getContent(documentId).observeForever { document ->
            _content.value = document
            val user = FirebaseAuth.getInstance().currentUser
            val favorites = document.get("favorite") as? List<*>
            _isFavorite.value = favorites?.contains(user?.uid) ?: false
        }
    }

    fun toggleFavorite(documentId: String, userId: String) {
        val currentFavoriteStatus = _isFavorite.value ?: false
        repository.toggleFavorite(documentId, userId, currentFavoriteStatus).observeForever { newFavoriteStatus ->
            _isFavorite.value = newFavoriteStatus
            _favoriteChangedEvent.value = true
        }
    }

    fun favoriteEventHandled() {
        _favoriteChangedEvent.value = false
    }

    fun fetchReviews(contentId: String) {
        repository.getReviews(contentId).observeForever { reviewList ->
            _reviews.value = reviewList
        }
    }

    fun addReview(documentId: String, review: Map<String, String>) {
        repository.addReview(documentId, review).observeForever { success ->
            if (success) fetchReviews(documentId)
        }
    }
}

class DetailViewModelFactory(private val repository: ContentRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DetailViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return DetailViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
