package com.bastianarf.desawisataponorogo.utilities

import com.bastianarf.desawisataponorogo.response.Photos
import com.bastianarf.desawisataponorogo.response.Reviews

data class Content(
    var documentId: String = "",
    val categories: String = "",
    val description: String = "",
    val gallery: List<Photos> = listOf(),
    val location: String = "",
    val mapsLink: String = "",
    val name: String = "",
    val youtubeLink: String = "",
    val reviews: List<Reviews> = listOf()
)

data class UserProfileResponse(
    val email: String = "",
    val fullName: String = "",
    val nickName: String = "",
    val bio: String = "",
    val avatar: String? = ""
)
data class Review(
    var userId: String = "",
    val fullName: String = "",
    val avatar: String? = "",
    val reviewId: String = "",
    val reviewText: String = ""

)


