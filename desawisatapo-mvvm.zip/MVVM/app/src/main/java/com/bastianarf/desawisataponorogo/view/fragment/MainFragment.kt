package com.bastianarf.desawisataponorogo.view.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.bastianarf.desawisataponorogo.adapters.MainAdapter
import com.bastianarf.desawisataponorogo.databinding.FragmentMainBinding
import com.bastianarf.desawisataponorogo.viewmodel.MainViewModel

class MainFragment : Fragment() {

    private var _binding: FragmentMainBinding? = null
    private val binding get() = _binding!!
    private lateinit var mainAdapter: MainAdapter
    private lateinit var viewModel: MainViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMainBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)

        val recyclerViewContent = binding.rvMain
        recyclerViewContent.layoutManager = LinearLayoutManager(context)
        mainAdapter = MainAdapter(requireContext(), mutableListOf())
        recyclerViewContent.adapter = mainAdapter

        viewModel.contents.observe(viewLifecycleOwner, Observer { contents ->
            mainAdapter.updateList(contents)
        })

        viewModel.fillingTheContent()
    }

    fun searchContents(query: String) {
        viewModel.searchContents(query)
    }

    fun filterContents(category: String) {
        if (category.isEmpty()) {
            viewModel.fillingTheContent()
        } else {
            viewModel.filterContents(category)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.d("MainFragment", "onDestroyView called")
        _binding = null
    }
}
