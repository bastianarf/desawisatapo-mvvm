package com.bastianarf.desawisataponorogo.viewmodel

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.bastianarf.desawisataponorogo.response.InputPhotoResponse
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import java.io.File

class InputBioViewModel : ViewModel() {
    private val _uploadResponse = MutableLiveData<InputPhotoResponse>()
    val uploadResponse: LiveData<InputPhotoResponse> = _uploadResponse

    private val _hasUploaded = MutableLiveData<File>()
    val hasUploaded: LiveData<File> = _hasUploaded

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val storageRef = FirebaseStorage.getInstance().reference
    private val firestore = FirebaseFirestore.getInstance()

    fun setFile(value: File) {
        _hasUploaded.value = value
    }

    fun uploadImage(userId: String, file: File, bio: String) {
        _isLoading.value = true
        val fileRef = storageRef.child("avatar/${file.name}")
        val uri = Uri.fromFile(file)

        fileRef.putFile(uri)
            .addOnSuccessListener {
                fileRef.downloadUrl.addOnSuccessListener { downloadUri ->
                    val userBioData = hashMapOf(
                        "bio" to bio,
                        "avatar" to downloadUri.toString()
                    )

                    firestore.collection("users").document(userId)
                        .set(userBioData, SetOptions.merge())
                        .addOnSuccessListener {
                            _uploadResponse.value = InputPhotoResponse(true, "Upload successful")
                            _isLoading.value = false
                        }
                        .addOnFailureListener { e ->
                            _uploadResponse.value = InputPhotoResponse(false, e.message ?: "Unknown error occurred")
                            _isLoading.value = false
                        }
                }.addOnFailureListener { e ->
                    _uploadResponse.value = InputPhotoResponse(false, e.message ?: "Unknown error occurred")
                    _isLoading.value = false
                }
            }
            .addOnFailureListener { e ->
                _uploadResponse.value = InputPhotoResponse(false, e.message ?: "Unknown error occurred")
                _isLoading.value = false
            }
    }
}