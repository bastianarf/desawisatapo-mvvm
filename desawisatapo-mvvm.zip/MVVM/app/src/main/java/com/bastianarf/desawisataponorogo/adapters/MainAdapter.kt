package com.bastianarf.desawisataponorogo.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bastianarf.desawisataponorogo.R
import com.bastianarf.desawisataponorogo.response.Photos
import com.bastianarf.desawisataponorogo.utilities.Content
import com.bastianarf.desawisataponorogo.view.activity.DetailActivity
import com.bumptech.glide.Glide

class MainAdapter(private val context: Context?, private var contents: MutableList<Content>): RecyclerView.Adapter<MainAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var nameTV: TextView = itemView.findViewById(R.id.tv_name)
        var categoriesTV: TextView = itemView.findViewById(R.id.tv_categories)
        val displaylocTV: TextView = itemView.findViewById(R.id.tv_displayloc)
        val image: ImageView = itemView.findViewById(R.id.iv_content)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_main, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val content = contents[position]
        val name = content.name as? String
        val categories = content.categories as? String
        val location = content.location as? String
        val gallery = content.gallery as? ArrayList<Photos>
        val thumbnail = gallery?.get(0)?.link

        holder.nameTV.text = "$name"
        holder.categoriesTV.text = "$categories"
        when (holder.categoriesTV.text) {
            "Wisata Alam" -> holder.categoriesTV.setBackgroundResource(R.color.green_500)
            "Wisata Budaya" -> holder.categoriesTV.setBackgroundResource(R.color.red_500)
            "Wisata Buatan" -> holder.categoriesTV.setBackgroundResource(R.color.blue_500)
            "Wisata Religi" -> holder.categoriesTV.setBackgroundResource(R.color.gray_500)
            "Desa Wisata" -> holder.categoriesTV.setBackgroundResource(R.color.brown_500)
        }
        holder.displaylocTV.text = "$location"
        if (thumbnail != null) {
            val into = Glide.with(context!!)
                .load(thumbnail)
                .into(holder.image)
        }

        holder.itemView.setOnClickListener {
            val intent = Intent(context, DetailActivity::class.java)
            intent.putExtra("documentId",content.documentId)
            context!!.startActivity(intent)

        }
    }

    override fun getItemCount(): Int {
        return contents.size
    }

    fun updateList(newContents: List<Content>){
        contents.clear()
        contents.addAll(newContents)
        notifyDataSetChanged()
    }
}