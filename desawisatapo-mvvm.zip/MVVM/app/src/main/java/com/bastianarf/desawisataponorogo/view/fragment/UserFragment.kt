package com.bastianarf.desawisataponorogo.view.fragment

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.bastianarf.desawisataponorogo.R
import com.bastianarf.desawisataponorogo.viewmodel.UserViewModel
import com.bastianarf.desawisataponorogo.databinding.FragmentUserBinding
import com.bastianarf.desawisataponorogo.utilities.UserProfileResponse
import com.bastianarf.desawisataponorogo.view.activity.EditInputBioActivity
import com.bastianarf.desawisataponorogo.view.activity.LoginActivity
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class UserFragment : Fragment() {

    private var _binding: FragmentUserBinding? = null
    private lateinit var auth: FirebaseAuth
    private lateinit var userViewModel: UserViewModel

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentUserBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        auth = Firebase.auth
        userViewModel = ViewModelProvider(this)[UserViewModel::class.java]
        userViewModel.userProfileData.observe(viewLifecycleOwner) { userProfile ->
            displayUserProfile(userProfile)
        }
        userViewModel.getUserProfile()
    }

    private fun displayUserProfile(userProfile: UserProfileResponse?) {
        if (userProfile != null) {
            binding.tvFullName.text = resources.getString(R.string.profile_fullname, userProfile.fullName)
            binding.tvNickName.text = resources.getString(R.string.profile_nickname, userProfile.nickName)
            binding.tvEmail.text = resources.getString(R.string.profile_email, userProfile.email)
            binding.tvBio.text = resources.getString(R.string.profile_bio, userProfile.bio)
            Glide.with(requireContext())
                .load(userProfile.avatar)
                .into(binding.userAvatar)

            binding.btnEditProfile.setOnClickListener {
                val intent = Intent(requireContext(), EditInputBioActivity::class.java)
                startActivity(intent)
            }

            binding.btnLogout.setOnClickListener {
                signOut()
            }
        }
    }

    private fun signOut() {
        auth.signOut()
        val intent = Intent(requireContext(), LoginActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        requireActivity().finish()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}