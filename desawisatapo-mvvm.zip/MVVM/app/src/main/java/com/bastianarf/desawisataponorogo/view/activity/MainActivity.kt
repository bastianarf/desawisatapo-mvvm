package com.bastianarf.desawisataponorogo.view.activity

import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.ui.AppBarConfiguration
import com.bastianarf.desawisataponorogo.R
import com.bastianarf.desawisataponorogo.databinding.ActivityMainBinding
import com.bastianarf.desawisataponorogo.view.fragment.FavoriteFragment
import com.bastianarf.desawisataponorogo.view.fragment.MainFragment
import com.bastianarf.desawisataponorogo.view.fragment.UserFragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var appBarConfiguration: AppBarConfiguration
    private var activeButton: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navView: BottomNavigationView = binding.navView
        supportFragmentManager.beginTransaction().replace(R.id.fragment_container, MainFragment()).commit()
        navView.setSelectedItemId(R.id.navigation_home)
        navView.setOnItemSelectedListener { item ->
            var selectedFragment: Fragment? = null
            when (item.itemId) {
                R.id.navigation_home -> {
                    selectedFragment = MainFragment()
                }
                R.id.navigation_favorite -> {
                    selectedFragment = FavoriteFragment()
                }
                R.id.navigation_user -> {
                    selectedFragment = UserFragment()
                }
            }
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container, selectedFragment!!)
            transaction.commit()

            // Toggle visibility of horizontalTag based on selected fragment
            if (selectedFragment is MainFragment) {
                binding.horizontalTag.visibility = View.VISIBLE
            } else {
                binding.horizontalTag.visibility = View.GONE
            }

            true
        }
        actionBarWithOwnName()

        // Add click listeners for filter buttons
        binding.btnWisataAlam.setOnClickListener { toggleButtonState(it as Button, "Wisata Alam", R.color.green_500) }
        binding.btnWisataBudaya.setOnClickListener { toggleButtonState(it as Button, "Wisata Budaya", R.color.red_500) }
        binding.btnWisataBuatan.setOnClickListener { toggleButtonState(it as Button, "Wisata Buatan", R.color.blue_500) }
        binding.btnWisataReligi.setOnClickListener { toggleButtonState(it as Button, "Wisata Religi", R.color.gray_500) }
        binding.btnDesaWisata.setOnClickListener { toggleButtonState(it as Button, "Desa Wisata", R.color.brown_500) }

    }

    private fun toggleButtonState(button: Button, category: String, colorResId: Int) {
        if (activeButton == button) {
            // Deactivate the current button
            button.setBackgroundColor(ContextCompat.getColor(this, R.color.default_tag_color))
            button.setTextColor(ContextCompat.getColor(this, R.color.default_text_tag_color))
            activeButton = null
            filterContent("")  // Clear filter
        } else {
            // Activate the new button
            activeButton?.let {
                it.setBackgroundColor(ContextCompat.getColor(this, R.color.default_tag_color))
                it.setTextColor(ContextCompat.getColor(this, R.color.default_text_tag_color))
            }
            button.setBackgroundColor(ContextCompat.getColor(this, colorResId))
            button.setTextColor(ContextCompat.getColor(this, R.color.white))
            activeButton = button
            filterContent(category)  // Apply filter
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        val searchItem = menu?.findItem(R.id.menu_search)
        val searchView = searchItem?.actionView as SearchView
        searchView.queryHint = "Cari..."

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (query != null) {
                    performSearch(query)
                }
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText != null) {
                    performSearch(newText)
                }
                return false
            }
        })

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_maps -> {
                MapsActivity.start(this)
            }
        }
        return true
    }

    private fun performSearch(query: String) {
        val fragment = supportFragmentManager.findFragmentById(R.id.fragment_container)
        if (fragment is MainFragment) {
            fragment.searchContents(query)
        }
    }

    private fun filterContent(category: String) {
        val fragment = supportFragmentManager.findFragmentById(R.id.fragment_container)
        if (fragment is MainFragment) {
            fragment.filterContents(category)
        }
    }

    private fun actionBarWithOwnName() {
        val user = FirebaseAuth.getInstance().currentUser
        val db = FirebaseFirestore.getInstance()

        if (user != null) {
            val docRef = db.collection("users").document(user.uid)
            docRef.get().addOnSuccessListener { document ->
                if (document != null) {
                    val nickName = document.getString("nickName")
                    supportActionBar?.title = "Halo, $nickName!"
                } else {
                    Log.d(TAG, "No such document!")
                }
            }
                .addOnFailureListener { exception ->
                    Log.d(TAG, "get failed with ", exception)
                }
        }
    }

    companion object {
        private const val TAG = "MainActivity"
    }
}
