package com.bastianarf.desawisataponorogo.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.bastianarf.desawisataponorogo.model.FavoriteRepository
import com.bastianarf.desawisataponorogo.utilities.Content

class FavoriteViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: FavoriteRepository = FavoriteRepository()

    val favoriteContents: LiveData<List<Content>> = repository.favoriteContents

    fun fetchFavorites(userId: String) {
        repository.fetchFavorites(userId)
    }
}
