package com.bastianarf.desawisataponorogo.response

data class Reviews(
    val userId : String = "",
    val reviewId : String = "",
    val review : String = ""
)