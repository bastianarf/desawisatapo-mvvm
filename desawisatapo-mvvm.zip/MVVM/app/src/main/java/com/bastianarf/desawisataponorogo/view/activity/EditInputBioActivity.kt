package com.bastianarf.desawisataponorogo.view.activity
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.ViewModelProvider
import com.bastianarf.desawisataponorogo.viewmodel.EditInputBioViewModel
import com.bastianarf.desawisataponorogo.R
import com.bastianarf.desawisataponorogo.databinding.ActivityEditInputBioBinding
import com.bastianarf.desawisataponorogo.utilities.UserProfileResponse
import com.bastianarf.desawisataponorogo.utilities.createCustomTempFile
import com.bastianarf.desawisataponorogo.utilities.rotateImage
import com.bastianarf.desawisataponorogo.utilities.uriToFile
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import java.io.File
import java.io.FileOutputStream

class EditInputBioActivity : AppCompatActivity() {
    private lateinit var binding: ActivityEditInputBioBinding
    private lateinit var viewModel: EditInputBioViewModel
    private lateinit var currentPhotoPath: String
    private var getFile: File? = null

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (!allPermissionsGranted()) {
                Toast.makeText(
                    this, R.string.unauthorized_perm,
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditInputBioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this).get(EditInputBioViewModel::class.java)

        if (!allPermissionsGranted()) {
            ActivityCompat.requestPermissions(
                this,
                REQUIRED_PERMISSIONS,
                REQUEST_CODE_PERMISSIONS
            )
        }

        setupListeners()
        setupObservers()

        // Fetch user profile from Firestore
        viewModel.getUserProfile().observe(this) { userProfile ->
            userProfile?.let {
                binding.inputFullName.setText(it.fullName)
                binding.inputNickName.setText(it.nickName)
                binding.inputBio.setText(it.bio)
                // Load image into ImageView
                if (!it.avatar.isNullOrEmpty()) {
                    Glide.with(this).load(it.avatar).into(binding.ivThumbnail)
                }
            }
        }
    }
    private fun setupListeners() {
        binding.apply {
            btnCamera.setOnClickListener { startTakePhoto() }
            btnGallery.setOnClickListener { startGallery() }
            btnEditInput.setOnClickListener { saveProfile() }
            btnEditInput.isEnabled = false

            inputBio.addTextChangedListener {
                val isBioEmpty = it.isNullOrEmpty()
                val isImageSelected = getFile != null
                btnEditInput.isEnabled = !isBioEmpty && isImageSelected
            }
        }
    }

    private fun setupObservers(){
        viewModel.uploadResponse.observe(this) { response ->
            if (response.success) {
                Toast.makeText(this, response.message, Toast.LENGTH_SHORT).show()
                // Load image into ImageView
                response.photoUrl?.let {
                    Glide.with(this).load(it).into(binding.ivThumbnail)
                }
            } else {
                Toast.makeText(this, response.message, Toast.LENGTH_SHORT).show()
            }
        }

    }
    private fun startGallery() {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        intent.type = "image/*"
        val chooser = Intent.createChooser(intent, "Pilih Gambar")
        launcherIntentGallery.launch(chooser)
    }

    private fun startTakePhoto() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.resolveActivity(packageManager)

        createCustomTempFile(application).also {
            val photoURI: Uri = FileProvider.getUriForFile(this@EditInputBioActivity, "com.bastianarf.desawisataponorogo", it)
            currentPhotoPath = it.absolutePath
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
            launcherIntentCamera.launch(intent)
        }
    }

    private val launcherIntentCamera = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == RESULT_OK) {
            val myFile = File(currentPhotoPath)
            myFile.let { file ->
                val bitmap = BitmapFactory.decodeFile(file.path)
                rotateImage(bitmap, currentPhotoPath).compress(
                    Bitmap.CompressFormat.JPEG,
                    100,
                    FileOutputStream(file)
                )
                setFile(file)
            }
        }
    }

    private val launcherIntentGallery = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val selectedImg = result.data?.data as Uri

            selectedImg.let { uri ->
                val myFile = uriToFile(uri, this)
                setFile(myFile)
            }
        }
    }

    private fun saveProfile(){
        getFile?.let { file ->
            val email = FirebaseAuth.getInstance().currentUser?.email.toString()
            val fullName = binding.inputFullName.text.toString()
            val nickName = binding.inputNickName.text.toString()
            val bio = binding.inputBio.text.toString()
            viewModel.uploadImage(file)
            viewModel.uploadResponse.observe(this) { response ->
                if(response.success){
                    val avatar = response.photoUrl.toString()
                    val userProfile = UserProfileResponse(email, fullName, nickName, bio,
                        avatar)
                    viewModel.updateUserProfile(userProfile, onSuccess = {
                        Toast.makeText(this, "Profile updated successfully", Toast.LENGTH_SHORT).show()
                        goToMainActivity()
                    }, onFailure = {
                        Toast.makeText(this, "Profile update failed", Toast.LENGTH_SHORT).show()
                    })
                }
            }
        }
    }

    private fun goToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun setFile(file: File){
        getFile = file
        // Enable the button if the bio is not empty
        binding.btnEditInput.isEnabled = !binding.inputBio.text.isNullOrEmpty()
        viewModel.setFile(file)
    }


    companion object {
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10

        @JvmStatic
        fun start(context: Context) {
            val starter = Intent(context, EditInputBioActivity::class.java)
            context.startActivity(starter)
        }
    }
}
