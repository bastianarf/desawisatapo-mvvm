package com.bastianarf.desawisataponorogo.view.activity

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager.widget.ViewPager
import com.bastianarf.desawisataponorogo.view.fragment.DetailFragment
import com.bastianarf.desawisataponorogo.viewmodel.DetailViewModel
import com.bastianarf.desawisataponorogo.viewmodel.DetailViewModelFactory
import com.bastianarf.desawisataponorogo.R
import com.bastianarf.desawisataponorogo.adapters.ImageAdapter
import com.bastianarf.desawisataponorogo.databinding.ActivityDetailBinding
import com.bastianarf.desawisataponorogo.model.ContentRepository
import com.bastianarf.desawisataponorogo.utilities.Content
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    private lateinit var detailViewModel: DetailViewModel
    private var isFavorite = false // To track if the item is already favorited

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val documentId = intent.getStringExtra("documentId")

        if (documentId != null) {
            val detailFragment = DetailFragment().apply {
                arguments = Bundle().apply {
                    putString("contentId", documentId)
                }
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container_add_review, detailFragment)
                .commitNow()
        }

        firebaseAuth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        val repository = ContentRepository()
        val factory = DetailViewModelFactory(repository)
        detailViewModel = ViewModelProvider(this, factory).get(DetailViewModel::class.java)

        actionBarWithDestinationTitle()
        fetchingData()
        observeViewModel()
    }

    private fun observeViewModel() {
        detailViewModel.isFavorite.observe(this) {isFavorite ->
            this.isFavorite = isFavorite
            invalidateOptionsMenu()
        }

        detailViewModel.favoriteChangedEvent.observe(this) { event ->
            if (event == true) {
                val message = if (isFavorite) {
                    getString(R.string.marked_as_favorite)
                } else {
                    getString(R.string.removed_from_favorites)
                }
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                detailViewModel.favoriteEventHandled()
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.detail_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_favorite -> {
                val user = firebaseAuth.currentUser
                val documentId = intent.getStringExtra("documentId")
                if (user != null && documentId != null) {
                    detailViewModel.toggleFavorite(documentId, user.uid)
                }
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun actionBarWithDestinationTitle() {
        val user = firebaseAuth.currentUser
        val documentId = intent.getStringExtra("documentId")
        if (user != null && documentId != null) {
            detailViewModel.fetchContent(documentId)
            detailViewModel.content.observe(this) { document ->
                val title = document.getString("name")
                supportActionBar?.title = title
                isFavorite = document.get("favorite")?.let {
                    (it as? List<*>)?.contains(user.uid) ?: false
                } ?: false
                invalidateOptionsMenu()
            }
        }
    }

    override fun onPrepareOptionsMenu(menu: Menu?): Boolean {
        super.onPrepareOptionsMenu(menu)
        val favoriteItem = menu?.findItem(R.id.menu_favorite)
        if (isFavorite) {
            favoriteItem?.setIcon(R.drawable.ic_baseline_favorite_24)
        } else {
            favoriteItem?.setIcon(R.drawable.ic_baseline_favorite_border_24)
        }
        return true
    }

    private fun fetchingData() {
        val user = firebaseAuth.currentUser
        val documentId = intent.getStringExtra("documentId")
        if (user != null && documentId != null) {
            detailViewModel.fetchContent(documentId)
            detailViewModel.content.observe(this) { document ->
                val itemDetail = document.toObject(Content::class.java)
                binding.tvCategories.text = itemDetail?.categories
                when (binding.tvCategories.text) {
                    "Wisata Alam" -> binding.tvCategories.setBackgroundResource(R.color.green_500)
                    "Wisata Budaya" -> binding.tvCategories.setBackgroundResource(R.color.red_500)
                    "Wisata Buatan" -> binding.tvCategories.setBackgroundResource(R.color.blue_500)
                    "Wisata Religi" -> binding.tvCategories.setBackgroundResource(R.color.gray_500)
                    "Desa Wisata" -> binding.tvCategories.setBackgroundResource(R.color.brown_500)
                }
                binding.tvItemDescription.text = itemDetail?.description
                val youtube = itemDetail?.youtubeLink
                val videoId = extractYoutubeVideoId(youtube)
                val webSettings = binding.youtubeWebview.settings
                webSettings.javaScriptEnabled = true
                binding.youtubeWebview.loadUrl("https://www.youtube.com/embed/$videoId")

                val gallery = document.get("gallery") as List<Map<String, String>>
                val imageLinks = gallery.map { it["link"]!! }
                val adapter = ImageAdapter(this, imageLinks)
                binding.carouselPhoto.findViewById<ViewPager>(R.id.view_pager).adapter = adapter

                val favorites = document.get("favorite") as? MutableList<String>
                if (favorites == null) {
                    firestore.collection("contents").document(documentId).update("favorite", mutableListOf<String>())
                }
                isFavorite = favorites?.contains(user.uid) == true
                invalidateOptionsMenu()
            }
        }
    }

    private fun extractYoutubeVideoId(youtubeLink: String?): String? {
        val youtubePatterns = listOf(
            "youtu.be/([a-zA-Z0-9_-]+)",
            "youtube.com/watch\\?v=([a-zA-Z0-9_-]+)",
            "youtube.com/embed/([a-zA-Z0-9_-]+)",
            "youtube.com/v/([a-zA-Z0-9_-]+)"
        )
        youtubeLink?.let {
            for (pattern in youtubePatterns) {
                val regex = Regex(pattern)
                val matchResult = regex.find(it)
                if (matchResult != null) {
                    return matchResult.groupValues[1]
                }
            }
        }
        return null
    }

    companion object {
        private const val TAG = "DetailActivity"
    }
}
