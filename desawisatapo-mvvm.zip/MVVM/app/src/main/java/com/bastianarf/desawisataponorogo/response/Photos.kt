package com.bastianarf.desawisataponorogo.response

data class Photos(
    val link: String = ""
)

data class InputPhotoResponse(
    val success: Boolean,
    val message: String
)

data class EditInputPhotoResponse(
    val success: Boolean,
    val message: String,
    val photoUrl: String? = null
)