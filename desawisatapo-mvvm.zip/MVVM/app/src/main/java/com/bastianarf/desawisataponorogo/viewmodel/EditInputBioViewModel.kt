package com.bastianarf.desawisataponorogo.viewmodel

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.bastianarf.desawisataponorogo.response.EditInputPhotoResponse
import com.bastianarf.desawisataponorogo.utilities.UserProfileResponse
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.ktx.storage
import java.io.File

class EditInputBioViewModel : ViewModel() {
    private val _uploadResponse = MutableLiveData<EditInputPhotoResponse>()
    val uploadResponse: LiveData<EditInputPhotoResponse> = _uploadResponse

    private val _hasUploaded = MutableLiveData<File>()
    val hasUploaded: LiveData<File> = _hasUploaded

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
    private val firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance()
    private val storage: FirebaseStorage = Firebase.storage

    fun setFile(value: File) {
        _hasUploaded.value = value
    }

    fun uploadImage(file: File) {
        _isLoading.value = true
        val fileRef = storage.reference.child("avatar/${file.name}")
        val uploadTask = fileRef.putFile(Uri.fromFile(file))

        uploadTask.addOnFailureListener {
            _isLoading.value = false
            _uploadResponse.value = EditInputPhotoResponse(success = false, message = "Upload failed")
        }.addOnSuccessListener {
            fileRef.downloadUrl.addOnSuccessListener { uri ->
                _isLoading.value = false
                _uploadResponse.value = EditInputPhotoResponse(success = true, message = "Upload successful", photoUrl = uri.toString())
            }
        }
    }

    fun getUserProfile(): MutableLiveData<UserProfileResponse?> {
        val userProfileLiveData = MutableLiveData<UserProfileResponse?>()
        val currentUser = firebaseAuth.currentUser

        currentUser?.let {
            val userId = it.uid
            val userRef = firestore.collection("users").document(userId)

            userRef.get().addOnSuccessListener { document ->
                if (document.exists()) {
                    val userProfile = document.toObject(UserProfileResponse::class.java)
                    userProfileLiveData.value = userProfile
                }
            }
        }

        return userProfileLiveData
    }

    fun updateUserProfile(userProfile: UserProfileResponse, onSuccess: ()-> Unit, onFailure: ()-> Unit) {
        val currentUser = firebaseAuth.currentUser

        currentUser?.let {
            val userId = it.uid
            val userRef = firestore.collection("users").document(userId)

            userRef.set(userProfile, SetOptions.merge())
                .addOnSuccessListener {
                    onSuccess()
                }
                .addOnFailureListener {
                    onFailure()
                }
        }
    }


}


