package com.bastianarf.desawisataponorogo.model

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.bastianarf.desawisataponorogo.utilities.Content
import com.google.firebase.firestore.FirebaseFirestore

class FavoriteRepository {

    private val _favoriteContents = MutableLiveData<List<Content>>()
    val favoriteContents: LiveData<List<Content>> = _favoriteContents

    fun fetchFavorites(userId: String) {
        val db = FirebaseFirestore.getInstance()
        val favoriteList = db.collection("contents").whereArrayContains("favorite", userId)
        favoriteList.get()
            .addOnSuccessListener { documents ->
                val contents = mutableListOf<Content>()
                for (document in documents) {
                    val content = document.toObject(Content::class.java)
                    content.documentId = document.id
                    contents.add(content)
                }
                _favoriteContents.value = contents
            }
            .addOnFailureListener { exception ->
                Log.d("konten", "get failed with : ", exception)
            }
    }
}
