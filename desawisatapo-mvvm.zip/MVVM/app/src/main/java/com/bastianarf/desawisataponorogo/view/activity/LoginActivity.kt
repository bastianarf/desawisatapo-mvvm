package com.bastianarf.desawisataponorogo.view.activity

// LoginActivity.kt
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.bastianarf.desawisataponorogo.R
import com.bastianarf.desawisataponorogo.databinding.ActivityLoginBinding
import com.bastianarf.desawisataponorogo.viewmodel.LoginViewModel

// LoginActivity.kt
class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var loginViewModel: LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Use DataBindingUtil to inflate the layout
        binding = DataBindingUtil.setContentView(this,
            R.layout.activity_login
        )

        loginViewModel = ViewModelProvider(this, ViewModelProvider.AndroidViewModelFactory.getInstance(application))
            .get(LoginViewModel::class.java)

        // Set lifecycle owner to enable LiveData observation
        binding.lifecycleOwner = this

        // Bind the ViewModel to the layout
        binding.viewModel = loginViewModel

        setupObservers()
        setupListeners()
    }

    private fun setupObservers() {
        loginViewModel.isLoginEnabled.observe(this) { isEnabled ->
            binding.btnLogin.isEnabled = isEnabled
        }

        loginViewModel.loginError.observe(this) { error ->
            error?.let {
                Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
            }
        }

        loginViewModel.navigateToInputBio.observe(this) { shouldNavigate ->
            if (shouldNavigate == true) {
                startActivity(Intent(this, InputBioActivity::class.java))
                finish()
            }
        }

        loginViewModel.navigateToMain.observe(this) { shouldNavigate ->
            if (shouldNavigate == true) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        }
    }

    private fun setupListeners() {
        binding.toRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
        binding.btnLogin.setOnClickListener {
            loginViewModel.signIn()
        }
        binding.etLoginEmail.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                loginViewModel.email.value = s.toString()
            }
        })
        binding.etLoginPassword.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                loginViewModel.password.value = s.toString()
            }
        })
    }

    override fun onStart() {
        super.onStart()
        val currentUser = loginViewModel.auth.currentUser
        if (currentUser != null) {
            loginViewModel.checkUserDetails()
        }
    }
}

