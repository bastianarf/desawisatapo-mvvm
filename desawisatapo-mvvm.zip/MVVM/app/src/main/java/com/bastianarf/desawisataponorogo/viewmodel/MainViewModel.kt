package com.bastianarf.desawisataponorogo.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.bastianarf.desawisataponorogo.model.MainRepository
import com.bastianarf.desawisataponorogo.utilities.Content

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MainRepository = MainRepository()
    val contents: LiveData<List<Content>> = repository.contents

    fun searchContents(query: String) {
        repository.searchContents(query)
    }

    fun filterContents(category: String) {
        repository.filterContents(category)
    }

    fun fillingTheContent() {
        repository.fillingTheContent()
    }
}
