package com.bastianarf.desawisataponorogo.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.viewpager.widget.PagerAdapter
import com.bastianarf.desawisataponorogo.R
import com.bumptech.glide.Glide

class ImageAdapter(private val context: Context, private val imageLinks: List<String>): PagerAdapter() {

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view == `object`
    }

    override fun getCount(): Int {
        return imageLinks.size
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val imageView = LayoutInflater.from(context).inflate(R.layout.item_carousel_image, container, false) as ImageView
        Glide.with(context).load(imageLinks[position]).into(imageView)
        container.addView(imageView)
        return imageView
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        container.removeView(`object` as ImageView)
    }
}