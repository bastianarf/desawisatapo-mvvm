package com.bastianarf.desawisataponorogo.model

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.bastianarf.desawisataponorogo.utilities.Review
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

class ContentRepository {
    private val firestore = FirebaseFirestore.getInstance()
    private val firebaseAuth = FirebaseAuth.getInstance()

    fun getContent(documentId: String): LiveData<DocumentSnapshot> {
        val contentLiveData = MutableLiveData<DocumentSnapshot>()
        firestore.collection("contents").document(documentId).get()
            .addOnSuccessListener { document ->
                contentLiveData.value = document
            }
            .addOnFailureListener { exception ->
                Log.d(TAG, "get failed with ", exception)
            }
        return contentLiveData
    }

    fun toggleFavorite(documentId: String, userId: String, isFavorite: Boolean): LiveData<Boolean> {
        val favoriteLiveData = MutableLiveData<Boolean>()
        val docRef = firestore.collection("contents").document(documentId)
        firestore.runTransaction { transaction ->
            val snapshot = transaction.get(docRef)
            val favorites = snapshot.get("favorite") as? MutableList<String> ?: mutableListOf()
            if (isFavorite) {
                favorites.remove(userId)
            } else {
                favorites.add(userId)
            }
            transaction.update(docRef, "favorite", favorites)
        }.addOnSuccessListener {
            favoriteLiveData.value = !isFavorite

        }.addOnFailureListener { e ->
            Log.w(TAG, "Transaction failure", e)
            favoriteLiveData.value = isFavorite
        }
        return favoriteLiveData
    }

    fun addReview(documentId: String, review: Map<String, String>): LiveData<Boolean> {
        val reviewLiveData = MutableLiveData<Boolean>()
        val contentRef = firestore.collection("contents").document(documentId)
        contentRef.update("reviews", FieldValue.arrayUnion(review))
            .addOnSuccessListener {
                reviewLiveData.value = true
            }
            .addOnFailureListener { e ->
                Log.w("DetailFragment", "Error adding review", e)
                reviewLiveData.value = false
            }
        return reviewLiveData
    }

    fun getReviews(contentId: String): LiveData<List<Review>> {
        val reviewsLiveData = MutableLiveData<List<Review>>()
        val contentRef = firestore.collection("contents").document(contentId)
        contentRef.get().addOnSuccessListener { documentSnapshot ->
            if (documentSnapshot.exists()) {
                val reviews = documentSnapshot.get("reviews") as? List<Map<String, String>>
                val reviewList = mutableListOf<Review>()
                reviews?.forEach { reviewMap ->
                    val userId = reviewMap["userId"] ?: ""
                    val reviewId = reviewMap["reviewId"] ?: ""
                    val reviewText = reviewMap["reviewText"] ?: ""
                    firestore.collection("users").document(userId).get().addOnSuccessListener { userSnapshot ->
                        if (userSnapshot.exists()) {
                            val fullName = userSnapshot.getString("fullName") ?: ""
                            val avatar = userSnapshot.getString("avatar")
                            val review = Review(userId, fullName, avatar, reviewId, reviewText)
                            reviewList.add(review)
                            if (reviewList.size == reviews.size) {
                                reviewsLiveData.value = reviewList
                            }
                        }
                    }
                }
            } else {
                reviewsLiveData.value = emptyList()
            }
        }
        return reviewsLiveData
    }

    companion object {
        private const val TAG = "ContentRepository"
    }
}