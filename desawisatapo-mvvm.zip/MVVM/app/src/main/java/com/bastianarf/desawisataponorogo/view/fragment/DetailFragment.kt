package com.bastianarf.desawisataponorogo.view.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bastianarf.desawisataponorogo.viewmodel.DetailViewModel
import com.bastianarf.desawisataponorogo.viewmodel.DetailViewModelFactory
import com.bastianarf.desawisataponorogo.R
import com.bastianarf.desawisataponorogo.adapters.AddReviewAdapter
import com.bastianarf.desawisataponorogo.adapters.ReviewAdapter
import com.bastianarf.desawisataponorogo.model.ContentRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.UUID

class DetailFragment : Fragment() {

    private lateinit var firestore: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var addReviewAdapter: AddReviewAdapter
    private lateinit var reviewAdapter: ReviewAdapter
    private var contentId: String? = null
    private lateinit var tvEmpty: TextView
    private lateinit var detailViewModel: DetailViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            contentId = it.getString("contentId")
        }
        firestore = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        val repository = ContentRepository()
        val factory = DetailViewModelFactory(repository)
        detailViewModel = ViewModelProvider(this, factory).get(DetailViewModel::class.java)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_detail, container, false)

        tvEmpty = view.findViewById(R.id.tv_empty)

        val rvAddReview: RecyclerView = view.findViewById(R.id.rv_add_review)
        rvAddReview.layoutManager = LinearLayoutManager(context)
        addReviewAdapter = AddReviewAdapter { reviewText ->
            addReview(reviewText)
        }
        rvAddReview.adapter = addReviewAdapter
        addDummyReviewItem()

        val rvReviews: RecyclerView = view.findViewById(R.id.rv_reviews)
        rvReviews.layoutManager = LinearLayoutManager(context)
        rvReviews.minimumHeight = 350
        reviewAdapter = ReviewAdapter(requireContext(), mutableListOf())
        rvReviews.adapter = reviewAdapter

        fetchReviews()

        return view
    }

    private fun addDummyReviewItem() {
        auth.currentUser?.let { user ->
            val dummyReviewItem = mapOf(
                "userId" to user.uid,
                "reviewText" to "Masukkan Review"
            )
            addReviewAdapter.addReviewItem(dummyReviewItem)
        }
    }

    private fun fetchReviews() {
        contentId?.let {
            detailViewModel.fetchReviews(it)
            detailViewModel.reviews.observe(viewLifecycleOwner) { reviewList ->
                if (reviewList.isNotEmpty()) {
                    tvEmpty.visibility = View.GONE
                    reviewAdapter.updateList(reviewList)
                } else {
                    tvEmpty.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun addReview(reviewText: String) {
        auth.currentUser?.let { user ->
            val reviewId = UUID.randomUUID().toString()
            val review = hashMapOf(
                "userId" to user.uid,
                "reviewId" to reviewId,
                "reviewText" to reviewText
            )
            contentId?.let {
                detailViewModel.addReview(it, review)
            }
        } ?: Toast.makeText(requireContext(), "User not signed in", Toast.LENGTH_SHORT).show()
    }
}





