package com.bastianarf.desawisataponorogo.view.activity

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.ViewModelProvider
import com.bastianarf.desawisataponorogo.viewmodel.InputBioViewModel
import com.bastianarf.desawisataponorogo.R
import com.bastianarf.desawisataponorogo.databinding.ActivityInputBioBinding
import com.bastianarf.desawisataponorogo.utilities.createCustomTempFile
import com.bastianarf.desawisataponorogo.utilities.reduceFileImage
import com.bastianarf.desawisataponorogo.utilities.rotateImage
import com.bastianarf.desawisataponorogo.utilities.uriToFile
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.File
import java.io.FileOutputStream


class InputBioActivity : AppCompatActivity() {
    private lateinit var binding: ActivityInputBioBinding
    private lateinit var currentPhotoPath: String
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    private lateinit var storage: FirebaseStorage
    private lateinit var storageRef: StorageReference
    private lateinit var inputBioViewModel: InputBioViewModel
    private var getFile: File? = null

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (!allPermissionsGranted()) {
                Toast.makeText(
                    this, R.string.unauthorized_perm,
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInputBioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firestore = FirebaseFirestore.getInstance()
        firebaseAuth = FirebaseAuth.getInstance()
        inputBioViewModel = ViewModelProvider(this).get(InputBioViewModel::class.java)

        //storage = Firebase.storage
        //storageRef = storage.reference

        if(!allPermissionsGranted()) {
            ActivityCompat.requestPermissions(
                this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS
            )
        }

        binding.apply {
            btnCamera.setOnClickListener { startTakePhoto() }
            btnGallery.setOnClickListener { startGallery() }
            buttonAdd.setOnClickListener { uploadImage() }
            buttonAdd.isEnabled = false

            edAddBio.addTextChangedListener {
                val isBioEmpty = it.isNullOrEmpty()
                val isImageSelected = getFile != null
                buttonAdd.isEnabled = !isBioEmpty && isImageSelected
            }
        }

        inputBioViewModel.uploadResponse.observe(this) { response ->
            if(response.success) {
                AlertDialog.Builder(this).apply {
                    setTitle("Upload Successful")
                    setMessage("Profile updated successfully")
                    setPositiveButton("Ok") { _, _ ->
                        goToMainActivity()
                        finish()
                    }
                    create()
                    show()
                }
            } else {
                Toast.makeText(this, response.message, Toast.LENGTH_SHORT).show()
            }
        }

        inputBioViewModel.isLoading.observe(this) { isLoading ->
            binding.buttonAdd.isEnabled = !isLoading
        }

        inputBioViewModel.hasUploaded.observe(this) {file ->
            if (file != null) {
                getFile = file
                binding.ivThumbnail.setImageBitmap(BitmapFactory.decodeFile(file.path))
            } else {
                binding.ivThumbnail.setImageResource(R.drawable.ic_thumbnail_image)
            }
        }
    }

    private fun startGallery() {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        intent.type = "image/*"
        val chooser = Intent.createChooser(intent, "Pilih Gambar")
        launcherIntentGallery.launch(chooser)
    }

    private fun startTakePhoto() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.resolveActivity(packageManager)

        createCustomTempFile(application).also {
            val photoURI: Uri = FileProvider.getUriForFile(this@InputBioActivity, "com.bastianarf.desawisataponorogo", it)
            currentPhotoPath = it.absolutePath
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
            launcherIntentCamera.launch(intent)
        }
    }

    private val launcherIntentCamera = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == RESULT_OK) {
            val myFile = File(currentPhotoPath)
            myFile.let { file ->
                val bitmap = BitmapFactory.decodeFile(file.path)
                rotateImage(bitmap, currentPhotoPath).compress(
                    Bitmap.CompressFormat.JPEG,
                    100,
                    FileOutputStream(file)
                )
                setFile(file)
            }
        }
    }

    private val launcherIntentGallery = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val selectedImg = result.data?.data as Uri

            selectedImg.let { uri ->
                val myFile = uriToFile(uri, this)
                setFile(myFile)
            }
        }
    }

    private fun uploadImage() {
        if (getFile != null) {
            val bio = binding.edAddBio.text.toString()
            val file = reduceFileImage(getFile as File)
            val user = firebaseAuth.currentUser

            user?.let {
                inputBioViewModel.uploadImage(it.uid, file, bio)
            }
            /*
            COMMENT
            // get a reference to the firebase storage instance
            val storage = Firebase.storage
            // create a storage reference
            val storageRef = storage.reference
            // create a reference to the file to upload
            val fileRef = storageRef.child("avatar/${file.name}")
            // upload the file to firebase storage
            val uploadTask = fileRef.putFile(Uri.fromFile(file))
            // register observers to listen for when the download is done or if it falls
            uploadTask.addOnFailureListener {
                // Handle unsuccessful uploads
                Toast.makeText(this, "Upload foto gagal", Toast.LENGTH_SHORT).show()
            }.addOnSuccessListener {
                // Task succesful, get the download URL
                fileRef.downloadUrl.addOnSuccessListener { uri ->
                    // You can save this download URL to save in your database
                    Toast.makeText(this, "Upload foto berhasil", Toast.LENGTH_SHORT).show()

                    val user = firebaseAuth.currentUser
                    val addBioAva = hashMapOf(
                        "bio" to bio,
                        "avatar" to uri.toString()
                    )

                    firestore.collection("users").document(user?.uid!!)
                        .set(addBioAva, SetOptions.merge())
                        .addOnSuccessListener {
                            AlertDialog.Builder(this).apply {
                                setTitle("Registrasi Berhasil")
                                setMessage("Kembali ke halaman Sign In")
                                setPositiveButton("Ok") { _, _ ->
                                    goToMainActivity()
                                    finish()
                                }
                                create()
                                show()
                            }
                        }
                        .addOnFailureListener {
                            Toast.makeText(this, "Error adding document", Toast.LENGTH_SHORT).show()
                        }
                }
            }*/
        }
    }

    private fun setFile(file: File){
        getFile = file
        // Enable the button if the bio is not empty
        binding.buttonAdd.isEnabled = !binding.edAddBio.text.isNullOrEmpty()
    }

    private fun goToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }


    companion object {
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10

        @JvmStatic
        fun start(context: Context) {
            val starter = Intent(context, InputBioActivity::class.java)
            context.startActivity(starter)
        }
    }
}